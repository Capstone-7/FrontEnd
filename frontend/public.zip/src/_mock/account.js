// ----------------------------------------------------------------------

const account = {
  displayName: 'Admin PayOll',
  email: 'payoll@gmail.com',
  photoURL: '/assets/images/avatars/avatar_default.jpg',
};

export default account;
