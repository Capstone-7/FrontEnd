import React from "react";

const Biils = () => {
  return <div>Biils</div>;
};

export default Biils;
