import React from "react";

const CONST = {
  BASE_URL_API: `${process.env.REACT_APP_BASE_URL}/v1`,
};

export default CONST;
