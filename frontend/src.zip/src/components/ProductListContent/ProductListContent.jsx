import React from 'react'

import styles from '../../assets/styles/ProductListContent.module.css'

const ProductListContent = () => {
  return (
    <>
    <div className={styles.BackgroundProduct}>
      <div className="container d-flex justify-content-center align-items-center">
        <div className="row">
          <div className="col-12">
            <h1>Rasakan kemudahan dalam menuntaskan Beban Tagihan dalam satu aplikasi</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Beatae, nam similique libero minus vel recusandae modi incidunt distinctio eum possimus officia ullam eaque enim placeat reiciendis natus consectetur labore neque.</p>
          </div>
        </div>
      </div>
    </div>
    </>
  )
}

export default ProductListContent