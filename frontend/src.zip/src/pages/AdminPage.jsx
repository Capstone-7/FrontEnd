import React from 'react'

const AdminPage = () => {
  return (
    <div>
      Admin
    </div>
  )
}

export default AdminPage
