import React from 'react'
import Navigation from '../components/Navigation/Navigation'
import ProductListContent from '../components/ProductListContent/ProductListContent'

const PageProduct = () => {
  return (
    <>
    <Navigation />
    <ProductListContent />
    </>
  )
}

export default PageProduct