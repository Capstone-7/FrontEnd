import logo from './logo.svg';
import './App.css';
import SetUpRouters from './routers/SetUpRouters';

function App() {
  return (
    <SetUpRouters />
  );
}

export default App;
